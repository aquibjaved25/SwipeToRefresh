package com.example.aquib.swipetorefresh;

/**
 * Created by Aquib on 4/21/2017.
 *
 */

 class Bean {
    private String boysName;
    private String girlsName;

     Bean(String boysName, String girlsName) {
        this.boysName = boysName;
        this.girlsName = girlsName;
    }

     String getBoysName() {
        return boysName;
    }

    /*public void setBoysName(String boysName) {
    this.boysName = boysName;
    }*/

     String getGirlsName() {
        return girlsName;
    }

    /*public void setGirlsName(String girlsName) {
        this.girlsName = girlsName;
    }*/
}
